<!DOCTYPE html>
<html lang="en">

<head>
  <title>Dating Admin</title><meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="<?php echo e(Request::root()); ?>/assets/admin/css/bootstrap.min.css" />
  <link rel="stylesheet" href="<?php echo e(Request::root()); ?>/assets/admin/css/bootstrap-responsive.min.css" />
  <link rel="stylesheet" href="<?php echo e(Request::root()); ?>/assets/admin/css/matrix-login.css" />
  <link href="<?php echo e(Request::root()); ?>/assets/admin/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>

</head>

<?php echo $__env->yieldContent('auth'); ?>


<script src="<?php echo e(Request::root()); ?>/assets/admin/js/jquery.min.js"></script>
<script src="<?php echo e(Request::root()); ?>/assets/admin/js/matrix.login.js"></script>

</body>

</html>
