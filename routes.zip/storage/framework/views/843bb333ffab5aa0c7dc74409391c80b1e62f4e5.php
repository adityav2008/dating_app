<?php $__env->startSection('auth'); ?>

<div id="loginbox">
  <form method="post" action="<?php echo e(url('admin/password/email')); ?>" class="form-vertical">
    <?php echo e(csrf_field()); ?>

    <p class="normal_text">Enter your e-mail address below and we will send you instructions how to recover a password.</p>
    <div class="controls">
      <div class="main_input_box">
        <span class="add-on bg_lo">
          <i class="icon-envelope"></i>
        </span>
        <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
        <?php if($errors->has('email')): ?>
            <span class="help-block">
                <?php echo e($errors->first('email')); ?>

            </span>
        <?php endif; ?>
      </div>
    </div>
    <div class="form-actions">
      <span class="pull-left"><a href="<?php echo e(Request::root()); ?>/admin/login" class="flip-link btn btn-success" id="to-login">&laquo; Back to login</a></span>
      <span class="pull-right"><button type="submit" class="btn btn-info recover">Reecover</button></span>
    </div>
  </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout/auth_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>