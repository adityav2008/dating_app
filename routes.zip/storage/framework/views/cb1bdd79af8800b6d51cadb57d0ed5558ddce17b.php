<!DOCTYPE html>
<html lang="en">
<head>
<title>Dating Admin</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="<?php echo e(Request::root()); ?>/assets/admin/css/bootstrap.min.css" />
<link rel="stylesheet" href="<?php echo e(Request::root()); ?>/assets/admin/css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="<?php echo e(Request::root()); ?>/assets/admin/css/uniform.css" />
<link rel="stylesheet" href="<?php echo e(Request::root()); ?>/assets/admin/css/select2.css" />
<link rel="stylesheet" href="<?php echo e(Request::root()); ?>/assets/admin/css/fullcalendar.css" />
<link rel="stylesheet" href="<?php echo e(Request::root()); ?>/assets/admin/css/matrix-style.css" />
<link rel="stylesheet" href="<?php echo e(Request::root()); ?>/assets/admin/css/matrix-media.css" />
<link href="<?php echo e(Request::root()); ?>/assets/admin/font-awesome/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo e(Request::root()); ?>/assets/admin/css/jquery.gritter.css" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>

<?php echo $__env->make('admin/common/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('admin/common/sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('admin/common/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>
</html>
