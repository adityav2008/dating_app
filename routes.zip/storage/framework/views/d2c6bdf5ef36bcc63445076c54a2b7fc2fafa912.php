<?php $__env->startSection('content'); ?>
<div id="content">
  <div id="content-header">
    <div id="breadcrumb">
      <a href="<?php echo e(Request::root()); ?>/admin/dashboard" title="Go to Home" class="tip-bottom">
        <i class="icon-home"></i> Home
      </a>
      <a href="<?php echo e(Request::root()); ?>/admin/manage-menu/resource-menu" class="current">Resources Menu's</a>
    </div>
  </div>
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="span12">
        <?php if(session('success')): ?>
        <div class="alert alert-success">
          <button class="close" data-dismiss="alert">×</button>
          <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
        <div class="alert alert-error">
          <button class="close" data-dismiss="alert">×</button>
          <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
            <h5>Content </h5>
          </div>
          <div class="widget-content nopadding">
            <form action="<?php echo e(Request::root()); ?>/admin/cms/content/save" method="post" class="form-horizontal" enctype="multipart/form-data">
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
              <input type="hidden" name="content_id" value="" />
              <input type="hidden" name="action" value="edit" />
              <div class="control-group">
                <label class="control-label">Title :</label>
                <div class="controls">
                  <input type="text"  class="span11" name="title" placeholder="Enter Page Title" value="" />
                </div>
              </div>
              <div class="control-group">
                <label class="control-label">Page Content :</label>
                <div class="controls">
                  <textarea class="span11" id="page_content" name="page_content" ></textarea>
                </div>
              </div>
              <div class="form-actions">
                <button type="submit" class="btn btn-success">Save</button>
                <a href="" class="btn btn-danger">Cancel</a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>