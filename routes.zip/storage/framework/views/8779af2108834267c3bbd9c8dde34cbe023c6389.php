<?php $__env->startSection('auth'); ?>

<div id="loginbox">
  <form class="form-vertical" role="form" method="POST" action="<?php echo e(url('/admin/login')); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="control-group normal_text"> <h3><img src="<?php echo e(Request::root()); ?>/assets/admin/img/logo.png" alt="Logo" /></h3></div>
    <div class="control-group">
      <div class="controls">
        <div class="main_input_box">
          <span class="add-on bg_lg">
            <i class="icon-user"></i>
          </span>
          <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
          <?php if($errors->has('email')): ?>
              <span class="help-block">
                  <?php echo e($errors->first('email')); ?>

              </span>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <div class="control-group">
      <div class="controls">
        <div class="main_input_box">
          <span class="add-on bg_ly">
            <i class="icon-lock"></i>
          </span>
          <input id="password" type="password" class="form-control" name="password" required>
          <?php if($errors->has('password')): ?>
              <span class="help-block">
                <?php echo e($errors->first('password')); ?>

              </span>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <div class="form-actions">
      <span class="pull-left"><a href="<?php echo e(Request::root()); ?>/admin/password/reset" class="flip-link btn btn-info" id="to-recover">Lost password?</a></span>
      <span class="pull-right"><button type="submit" class="btn btn-success login" >Login</button></span>
    </div>
  </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout/auth_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>