<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Auth;

class DashboardCtrl extends Controller
{
    public function index(Request $request)
    {
      //dd(Auth::id());
      return view("admin.content.index");
      //$data = $request->session()->all();
      //dd($data);
    }
}
