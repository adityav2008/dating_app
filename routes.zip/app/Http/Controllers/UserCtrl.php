<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserCtrl extends Controller
{
    public function index(Request $request)
    {
      return view('admin.content.user_list');
    }

    public function changeUser(Request $request)
    {
      if($request->input('action') == 'add')
      {
        return view('admin.content.edit_user');
      }
    }
}
